#Attaching a file to R-studio
getwd()
setwd("C:/Users/18132/Desktop/My Docs/SDM/Ass4")
library(readxl)
islr_data=read_excel("College_ISLR.xlsx") 
attach(islr_data)
str(islr_data)
#Converting the character type binary variable of a college is private or not to factor
islr_data$Private<-as.factor(Private)   
#Histogram for both the dependent variable
hist(Enrollment)

# calculate the new column called enrollment rate
islr_data$enrate<-(Enrollment/Acceptance)*100  
#Histogram for both the dependent variable
hist(islr_data$enrate) 
hist(GradRate)
cor(PhD,TerminalDegree)
#Checking if there is big difference between the fees of Private and PUblic Colleges,
#so that we can consider Outstate fees as the changing factor for enrollment rate
plot(as.factor(Private),OutstateTuition)
df1<-islr_data[islr_data$Private=='Yes',]  
df2<-islr_data[islr_data$Private=='No',]
boxplot(df1$OutstateTuition)$out
boxplot(df2$OutstateTuition)$out
scatter.smooth(df1$OutstateTuition)
scatter.smooth(df2$OutstateTuition)
#Checking the Correlation of all the Variables
install.packages("corrplot")
library(corrplot)
df3<-rbind(df1,df2)
df3<-subset(df3,select=-c(College,Private))
corrplot(cor(df3),method="circle")



#2.Specify the appropriate model. Submit both your R code and your output. Be sure to test for appropriate assumptions and adjust your regression model as necessary.
# Creating Dataframe to calculate enrollment rate regression and graduation Rate regression
enroll<-subset(df3,select=c(OutstateTuition,RoomAndBoard,Books,PersonalExpense,StudentFacultyRatio,InstrExpend,GradRate,enrate))
grad<-subset(df3,select=c(Top10perc,Top25perc,FulltimeUG,ParttimeUG,StudentFacultyRatio,enrate,GradRate))

#Checking all possible regression model for erollment rate, as it is a rate and showing normal kind of distribution
#through histogram, so can consider it as a poisson distribution
hist(enroll$enrate) 
enreg1<-glm(enrate~.,data=enroll,family=poisson(link=log))
summary(enreg1)
plot(enreg1)
#Poisson models have over-dispersion since residual deviance > degrees of freedom.
#This means that estimates are correct, but standard errors are wrong and unaccounted for by the model.
#In this case, a quasi-poisson model or negative binomial model is appropriate.
enreg2<-glm(enrate~.,data=enroll,family=quasipoisson(link=log))
summary(enreg2)
enreg3<-glm.nb(enrate~.,data=enroll)
summary(enreg3)
stargazer(enlm,enreg1,enreg2,enreg3,type="text",title="Comparison for enrollment rate")

install.packages("stargazer")
library(stargazer)
#Checking all possible regression model for graduation rate, as it is a rate and showing normal kind of distribution
#through histogram, so can consider it as a poisson distribution
hist(grad$GradRate)
gradreg1<-glm(GradRate~.,data=grad,family=poisson(link=log))
summary(gradreg1)
plot(gradreg1)
gradreg4<-glm(GradRate~.,data=grad,family=quasipoisson(link=log))
summary(gradreg4)
gradreg5<-glm.nb(GradRate~.,data=grad)
summary(gradreg5)
stargazer(gradreg1,gradreg4,gradreg5,type="text",title="Comparison for grad rate")
#As the linearity plot shows the convex curve, we can try using squared interaction on enrate, 
#in order to decrease its estimated error
gradreg2<-glm(GradRate~.+I(enrate^2),data=grad,family=poisson(link=log))
summary(gradreg2)
plot(gradreg2)
#As the linearity plot shows the convex curve, we can try using squared interaction on enrate,Top 10%, Top 25% 
#in order to decrease its estimated error
gradreg3<-glm(GradRate~.+I(enrate^2)+I(Top10perc^2)+I(Top25perc^2),data=grad,family=poisson(link=log))
summary(gradreg3)
plot(gradreg3)

stargazer(gradreg1,gradreg2,gradreg3,type="text",title="Comparison for grad rate")
enlm<-lm(log(enrate)~.,data=enroll)
summary(enlm)
plot(enlm)

gradlm<-lm(GradRate~.,data=grad)
summary(gradlm)
plot(gradlm)
hist(log(enroll$enrate))
hist(GradRate)

gradlm<-lm((GradRate)~.+I(enrate^2),data=grad)
summary(gradlm)
plot(gradlm)
