getwd()
setwd("C:/Users/18132/Desktop/My Docs/SDM/Ass3")
library(readr)
hdi_data=read.csv("EconomistData.csv")
attach(hdi_data)
cor(HDI,HDI.Rank)
plot(HDI,HDI.Rank)
cor(CPI,HDI)
plot(CPI,HDI)
lines(lowess(CPI,HDI),col="red")


cor(as.numeric(Region),HDI)
plot(as.numeric(Region),HDI)
hdi_data$Region<-as.numeric(Region)
cor(HDI,hdi_data$Region)

plot(HDI,hdi_data$Region)
attach(hdi_data)

hdi_reg1<-lm(HDI~CPI+as.factor(Region),data=hdi_data)
summary(hdi_reg1)
confint(hdi_reg1)
plot(hdi_reg1)
qqnorm(resid(hdi_reg1))
qqline(resid(hdi_reg1))
plot(hdi_data$HDI,hdi_reg1$fitted.values,pch=19,main="Actual v. Fitted Values")
abline(0,1,col="red",lwd=3)

plot(HDI~CPI)
abline(0,0.1,col="red",lwd=3)
plot(HDI~log(CPI))
abline(0,0.5,col="red",lwd=3)





hdi_logreg<-lm(HDI~log(CPI)+as.factor(Region),data=hdi_data)
summary(hdi_logreg)
plot(hdi_logreg)
plot(hdi_data$HDI,hdi_logreg$fitted.values,pch=19,main="Actual v. Fitted Values")
abline(0,1,col="red",lwd=3)
qqnorm(resid(hdi_logreg))
qqline(resid(hdi_logreg))
plot(hdi_data$HDI,hdi_logreg$fitted.values)
abline(0,1,col="red",lwd=3)