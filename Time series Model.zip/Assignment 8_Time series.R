rm(list = ls())
setwd("C:/Users/18132/Desktop/My Docs/SDM/Ass 8")
library(readr)
en<-read.csv("Enrollments.csv")
en$time<-seq(1:nrow(en))

#1. We want to predict ROLL as our dependent variable. What do you think should be our 
#independent variables and why? Do you think there should be a lag variable, and if so, how many years of lag?
#Unemployment: Unemployment rate of this year will not affect the enrollment as the
#student is going to complete their studies afer four years.
#HGRAD(high school graduate): This can affect the enrollment, as the more number of students passed the high school,
#the more will apply for college.
#INC(Income): Income will affect the enrollment, as it is easy to pay the fees and the living expense if they
#have good income.

par(mfrow=c(3,2))
plot(en$ROLL)
acf(en$ROLL)
plot(diff(en$ROLL))
acf(diff(en$ROLL))
plot(diff(diff(en$ROLL)))
acf(diff(diff(en$ROLL)))
#According to above plot, as we can see that with the differentiation of 2 make the mean zero,the time series become more stationary
#and also most of the ACFs are between 95% confidence interval i.e. the two blue dotted lines, so the lag for this can be 1.

#2. Run a linear trend model (Model 1) of ROLL versus time (i.e., YEAR). Is time a good predictor of enrollment? Why?
enreg<-lm(ROLL~time,data=en)
par(mfrow=c(1,1))
plot(enreg)
library(lmtest)
dwtest(enreg)


#Time alone is not the good predictor of enrollment as it has the high
#autocorrelation in the residuals which we can see through the residual plot the darwin watson test.

#3. Now, run a regression model (Model 2) of ROLL versus the number of high-school graduates (HGRAD). Is student supply a good predictor of enrollment? 
#Why? Which variable predicts enrollment better: time or student supply?
enreg1<-lm(ROLL~HGRAD,data=en)
plot(enreg1)
library(lmtest)
dwtest(enreg1)

#Student supply is not good predictor of enrollment as it has high autocorrelation among residuals 
#as we can see in the plot and the dw test.


par(mfrow=c(1,3))
plot(en$time,enreg$residuals,xlab="Time")
lines(en$time,enreg$residuals)
plot(en$time,enreg1$residuals,xlab="Time")
lines(en$time,enreg1$residuals)
#Student supply is better than time as most of the residuals are around zero randomly
#, but we can still see some whiplash effect, which might improve by applying lags.




#4. Run a lagged regression model (Model 3) of ROLL versus lagged ROLL. How many lags would be appropriate? Is lagged 
#enrollment a good predictor of future enrollment? Which variable predicts enrollment best: time, student supply, or lagged enrollment? How do you know?

# to improve the whiplash effect and also to bring residuals around mean i.e. 0 line and decrease the autocorrelation, will try to apply one year lag and run the model
en$rlag1 <- c(NA, en$ROLL[1:nrow(en)-1])
enlag1<-lm(ROLL~rlag1,data=en)
dwtest(enlag1)

#As we can see there is still some autocorrelation in the residuals and many residuals are far than 
#mean, we can apply two years lag and check it 

en$rlag2 <- c(NA, NA,en$ROLL[1:27])
enlag2<-lm(ROLL~rlag1+rlag2,data=en)
dwtest(enlag2)
#As we can see in the above plot, the residuals are nearer to mean i.e. zero line , also it has less whiplash effect
#compared to last model plot, also as we can see through DW test that it has no autocorrelation, when adding two years lag
# but we can run three years lag and check if it improves it more.

en$rlag3 <- c(NA, NA,NA,en$ROLL[1:26])
enlag3<-lm(ROLL~rlag1+rlag2+rlag3,data=en)
plot(enlag3)

par(mfrow=c(1,3))
plot(enlag1$res~en[2:29,6],xlab="Time")
lines(enlag1$res~en[2:29,6])
plot(enlag2$res~en[3:29,6],xlab="Time")
lines(enlag2$res~en[3:29,6])
plot(enlag3$res~en[4:29,6],xlab="Time")
lines(enlag3$res~en[4:29,6])
dwtest(enlag3)
#As we can see in the above plot, the residuals again got far to mean 
#and also the dw test ,value is farther from 2 as compared to last model.
sqrt(mean((en$ROLL - predict(enreg, en)) ^ 2))
sqrt(mean((en$ROLL - predict(enreg1, en)) ^ 2))
sqrt(mean((en$ROLL[3:29] - predict(enlag2,en)[3:29]) ^ 2))

#So as we can see with all the results, the model with two years lag is better than alone time 
#and HGRAD and also RMSE of that model is better, i.e. it has less error.

#5. Create a scatterplot of actual enrollment versus year.
#On the same scatterplot, overlay the predicted enrollment values for Model 1. 
#Similarly, create another scatterplot for Model 2, and a third scatterplot for Model 3. 
#Plot all three graphs on one page and attach as Figure 1. Based on this Figure, 
#which model best characterizes enrollment? Why?
par(mfrow=c(1,1))
library(ggplot2)
gg1<-ggplot(en, aes(en$time, en$ROLL)) + geom_point() +
  geom_line(mapping=aes(en$time,enreg$fitted.values,colour="ROLL vs time"))


gg2<-ggplot(en, aes(en$time, en$ROLL)) + geom_point() +
  geom_line(mapping=aes(en$time,enreg1$fitted.values,colour="ROLL vs Hgrad"))

gg3<-ggplot(en, aes(en$time, en$ROLL)) + geom_point() +
  geom_line(en[3:29,],mapping=aes(en$time[3:29],enlag2$fitted.values[3:29],colour="Roll vs lagged"))

ggarrange(gg1,gg2,gg3)

#According to the above plots, the last models i.e. enlag2(Roll vs two year lagged roll), is best
#fitting the time vs roll plot among all three models.


#6. Investigate the autocorrelation of residuals in all three models.To that end, create a partial autocorrelation function plot for the residuals of Model 1 (and also for Models 2 and 3). Plot all three partial autocorrelation function graphs on one page and attach
#as Figure 2. Based on this Figure, which of the 3 models shows the least violation of the model assumptions?

par(mfrow=c(1,3))
pacf(enreg$residuals)
pacf(enreg1$residuals)
pacf(enlag2$residuals)
#As the residuals are distributed randomly among the mean i.e. zero line for the third model, we can say that 
# the third model is least violet the model assumptions.

#7. Lastly, combine Models 1, 2, and 3 into an overall model, predicting future enrollment 
#based on linear trend, student supply, and lagged enrollment. Use stargazer to compare the three models.

final<-lm(ROLL~time+HGRAD+rlag1+rlag2,data=en)
summary(final)
plot(final)
plot(final$res~en[3:29,6],xlab="Time")
lines(final$res~en[3:29,6])
ggplot(en, aes(en$time, en$ROLL)) + geom_point() +
  geom_line(en[3:29,],mapping=aes(en$time[3:29],final$fitted.values[3:29],colour="Roll vs lagged"))

library(stargazer)
stargazer(enreg,enreg1,enlag2,type="text")



  












