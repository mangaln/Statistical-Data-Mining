rm(list = ls())
setwd("C:/Users/18132/Desktop/My Docs/SDM/Ass_7")
library(foreign)
can<-read.table("LungCancer.txt",skip=15,header=F)
colnames(can)<-c("treatment","cell_type","survival","status","karnofsky_score","months","age","prior_chemo")
attach(can)
unique(survival)
table(status)
table(treatment)
table(cell_type)
table(age)
length(unique(age))
table(prior_chemo)

#1. We would like to see Kaplan-Meier survival 
#graphs for patients with the test vs standard treatment. Use this data to assess:
# As we want to assess patient survival rate based on test vs standard treatment,
# The Survival in days will be time, Status will be event and we have to take it on treatment that will give us standard or not
library(survival)
km <- survfit(Surv(survival, status) ~ treatment)
summary(km)

#install.packages("survminer")
library(survminer)
ggsurvplot(km,data=can,risk.table=TRUE,legend.labs=c("Chemotherapy","Chemotherapy with new drug"),break.time.by = 200,break.y.by = 0.2,title="Survival curve for lung cancer patient",xlab="Time in Days")


#semi-parametric(cox-proportional)
require("survival")
cox<- coxph(Surv(survival, status)~as.factor(treatment)+age+karnofsky_score+months+as.factor(prior_chemo),method="breslow")
summary(cox)
x#ggforest(cox3)

#parametric models
exp <- survreg(Surv(survival, status)~as.factor(treatment)+age+months+karnofsky_score+as.factor(prior_chemo), dist="exponential")
summary(exp)

weibull<- survreg(Surv(survival, status)~as.factor(treatment)+age+months+karnofsky_score+as.factor(prior_chemo), dist="weibull")
summary(weibull)

loglos<- survreg(Surv(survival, status)~as.factor(treatment)+age+months+karnofsky_score+as.factor(prior_chemo), dist="loglogistic")
summary(loglos)

library(stargazer)
stargazer(cox,exp,weibull, type="text")
